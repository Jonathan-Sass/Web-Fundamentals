//construct an algorithm that takes an array of
//coordinates and returns an optimal taco truck location
//Test by running several test cases

//Joe drives a taco truck in the booming town of Squaresburg. He uses an array of [x,y] coordinates 
//corresponding to the locations of his customers. He also uses an array of [x,y] as coordinates 
//corresponding to the location where he parks his truck. Customers walk from their location to his 
//truck, but Joe wants to minimize the total distance from his truck to his customers, so he's looking 
//for a better place to park. Feature request: given a customer coordinate array, return an optimal taco truck location.

//Optimal taco truck location = min avg distance from customers

function getRndInteger (min, max) {
    return Math.floor(Math.random() * (max - min)) + min;
}

var customer1 = [getRndInteger (-20, 20),getRndInteger (-20, 20)];//I decided to practice some RNG for kicks, so customer locations are RNG'ed, yay!
var customer2 = [getRndInteger (-20, 20),getRndInteger (-20, 20)];
var customer3 = [getRndInteger (-20, 20),getRndInteger (-20, 20)];
var customer4 = [getRndInteger (-20, 20),getRndInteger (-20, 20)];
var customer5 = [getRndInteger (-20, 20),getRndInteger (-20, 20)];
var customer6 = [getRndInteger (-20, 20),getRndInteger (-20, 20)];

var potentialCustomers = [customer1, customer2, customer3, customer4, customer5, customer6];//dropping customer locations into a common array
console.log (potentialCustomers);//array log for a reference point 

function optimalLocation(){
    var xSum = potentialCustomers[0][0];//var to hold and sum x coordinates
    var ySum = potentialCustomers[0][1];//var to hold and sum y coordinates

    for (i = 1; i < potentialCustomers.length; i++){//arrayteration to sum respective x and y coordinates
        xSum += potentialCustomers[i][0];
        ySum += potentialCustomers[i][1];
    }

    var xAvg = xSum / potentialCustomers.length;//avg of coords
    var yAvg = ySum / potentialCustomers.length;

    return [Math.round(xAvg), Math.round(yAvg)];
}
console.log (optimalLocation());