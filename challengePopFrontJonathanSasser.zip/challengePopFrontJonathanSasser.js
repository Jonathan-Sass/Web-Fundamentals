//construct an algorithm that removes and returns the value at the front of an array. 

var arrayToPop = [8,45,72,45,9,254,67,3,90,-16];
//store index 0
function popFront(){
    var index0 = arrayToPop[0];

    for (i = 0; i < arrayToPop.length - 1; i++){
        arrayToPop[i] = arrayToPop[i + 1];
    }
    arrayToPop.pop;

    return index0;
}
//shift all values forward
//pop array
console.log(arrayToPop);
console.log(popFront());
console.log(arrayToPop);