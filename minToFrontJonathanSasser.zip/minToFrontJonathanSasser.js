//Construct an algorithm that locates the minimum value in an array and move it to the front of the array.
//search through the array for the minimum value
//identify element space that was stored
//shift preceding values to the next index to make space for the min in index 0
//push min to index 0

var array = [17,67,5,35,-15,2,56,1,75];

function minToFront(){
    var min = array[0];
    for (var i = 1; i < array.length; i++){//locate the minimum value
        if (array[i] < min){
            min = array[i];
        }
    }
   
    for (i = 1; i < array.length; i++){//identify element space that was stored
        if (min === array[i]){
            var minIndex = i;
        }
    }

    for (i = minIndex; i >= 1; i--){//shift preceding values to the next index to make space for the min in index 0
        array[i] = array[i - 1];
    }
    
    array[0] = min;//push min to index 0
    
}
console.log(array);
minToFront();
console.log(array);